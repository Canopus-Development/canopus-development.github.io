import yfinance as yf
import pandas as pd
from scipy import stats
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error

# Step 1: Collect Stock Market Data
ticker_symbol = 'TATAMOTORS.NS'
ticker_data = yf.Ticker(ticker_symbol)
hist = ticker_data.history(period='1d', start='2020-1-1', end='2024-1-1')
hist.to_csv('tata_motors_stock_data.csv')

# Step 2: Clean and Preprocess the Data
data = pd.read_csv('tata_motors_stock_data.csv')

# Fill missing values
data.ffill(inplace=True)

# Remove duplicates
data.drop_duplicates(inplace=True)

# Normalize the data
scaler = MinMaxScaler()
data[['Open', 'High', 'Low', 'Close', 'Volume']] = scaler.fit_transform(data[['Open', 'High', 'Low', 'Close', 'Volume']])

# Feature engineering
data['SMA_50'] = data['Close'].rolling(window=50).mean()
data['Volatility'] = data['Close'].rolling(window=50).std()

# Remove outliers
data = data[(np.abs(stats.zscore(data[['Open', 'High', 'Low', 'Close', 'Volume']])) < 3).all(axis=1)]

data.to_csv('cleaned_tata_motors_stock_data.csv', index=False)

# Step 3: Train a Machine Learning Model
data = pd.read_csv('cleaned_tata_motors_stock_data.csv')

# Feature selection
features = data[['Open', 'High', 'Low', 'Volume', 'SMA_50', 'Volatility']]
target = data['Close']

# Split the data
X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=0.2, random_state=42)

# Initialize and train the model
model = RandomForestRegressor()
model.fit(X_train, y_train)

# Make predictions
predictions = model.predict(X_test)

# Evaluate the model
mae = mean_absolute_error(y_test, predictions)
print(f'Mean Absolute Error: {mae}')

# Step 4: Make Buy/Sell Decision
current_price = data.iloc[-1]['Close']
predicted_price = model.predict(pd.DataFrame([features.iloc[-1].values], columns=features.columns))[0]

if predicted_price > current_price:
    decision = "Buy"
else:
    decision = "Do not buy"

print(f'Current Price: {current_price}')
print(f'Predicted Price: {predicted_price}')
print(f'Decision: {decision}')
